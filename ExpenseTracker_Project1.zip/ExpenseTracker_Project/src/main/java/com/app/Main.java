package com.app;

import com.app.fibonacci.FibonacciGenerator;
import com.app.expense.ExpenseManager;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ExpenseManager expenseManager = new ExpenseManager();
        boolean running = true;

        while (running) {
            System.out.println("\n===== Java Application =====");
            System.out.println("1. Generate Fibonacci Series");
            System.out.println("2. Add Expense");
            System.out.println("3. View Expenses Report");
            System.out.println("4. Delete Expense by ID");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter number of terms: ");
                    int n = scanner.nextInt();
                    FibonacciGenerator.generateSeries(n);
                }
                case 2 -> expenseManager.addExpense(scanner);
                case 3 -> expenseManager.viewReport();
                case 4 -> {
                    System.out.print("Enter Expense ID to delete: ");
                    int id = scanner.nextInt();
                    expenseManager.deleteExpense(id);
                }
                case 5 -> running = false;
                default -> System.out.println("Invalid choice.");
            }
        }

        scanner.close();
    }
}