package com.app.expense;

import java.sql.*;
import java.util.Scanner;

public class ExpenseManager {
    private final String url = "jdbc:sqlite:expenses.db";

    public ExpenseManager() {
        try (Connection conn = DriverManager.getConnection(url)) {
            Statement stmt = conn.createStatement();
            stmt.execute("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, amount REAL, category TEXT, date TEXT)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addExpense(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(url)) {
            System.out.print("Enter amount: ");
            double amount = scanner.nextDouble();
            scanner.nextLine();
            System.out.print("Enter category: ");
            String category = scanner.nextLine();
            System.out.print("Enter date (YYYY-MM-DD): ");
            String date = scanner.nextLine();

            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO expenses (amount, category, date) VALUES (?, ?, ?)");
            pstmt.setDouble(1, amount);
            pstmt.setString(2, category);
            pstmt.setString(3, date);
            pstmt.executeUpdate();

            System.out.println("Expense added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewReport() {
        try (Connection conn = DriverManager.getConnection(url)) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM expenses");

            System.out.println("ID | Amount | Category | Date");
            while (rs.next()) {
                System.out.printf("%d | %.2f | %s | %s%n", rs.getInt("id"), rs.getDouble("amount"), rs.getString("category"), rs.getString("date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteExpense(int id) {
        try (Connection conn = DriverManager.getConnection(url)) {
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM expenses WHERE id = ?");
            pstmt.setInt(1, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Expense deleted.");
            } else {
                System.out.println("Expense not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}